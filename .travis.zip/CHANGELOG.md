
# 1.0.0
=======
* Updated Media Device Selection app to Connect to Room.
* Added an example app to demonstrate Network quality API.
* Added an example app to demonstrate Room State Changes.
* Added an example app to demonstrate Dominant Speaker API.
* Updated twilio-video to 2.0.0.
* Added an example app to demonstrate Codec Preferences API.
* Added an example app to demonstrate Bandwidth Constraints API.
* Added an example app to demonstrate Local Video Filter.
* Added an example app to demonstrate Local Video Snapshot.
* Added an example app to demonstrate Media Device Selection.
* Updated twilio-video to 1.0.0.
* Removed configuration profile.
* Consolidated the various twilio-video.js quickstarts into a single project.
